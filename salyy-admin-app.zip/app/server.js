const express = require('express');
const path = require('path');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');

const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

const PORT = process.env.PORT || 3000;
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'salyy';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'changeme123';
const SESSION_SECRET = process.env.SESSION_SECRET || 'dev-secret-change-me';

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  store: new pgSession({ pool, tableName: 'session', createTableIfMissing: true }),
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 } // 7 days
}));

async function init() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS reservations (
      id SERIAL PRIMARY KEY,
      service TEXT NOT NULL,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      note TEXT,
      created_at TIMESTAMPTZ DEFAULT now()
    );
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS admins (
      id SERIAL PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL
    );
  `);
  const { rows } = await pool.query('SELECT COUNT(*)::int AS n FROM admins');
  if (rows[0].n === 0) {
    const hash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    await pool.query('INSERT INTO admins (username, password_hash) VALUES ($1,$2)', [ADMIN_USERNAME, hash]);
    console.log('Admin account seeded:', ADMIN_USERNAME);
  }
}

function requireAuth(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'unauthorized' });
  return res.redirect('/admin');
}

// ---- Public site ----
app.use(express.static(path.join(__dirname, 'public')));

// ---- Public booking API ----
app.post('/api/reservations', async (req, res) => {
  try {
    const { service, date, time, name, phone, note } = req.body || {};
    if (!service || !date || !time || !name || !phone) {
      return res.status(400).json({ error: 'missing_fields' });
    }
    await pool.query(
      `INSERT INTO reservations (service, date, time, name, phone, note) VALUES ($1,$2,$3,$4,$5,$6)`,
      [service, date, time, name, phone, note || '']
    );
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server_error' });
  }
});

// ---- Admin auth ----
app.post('/api/admin/login', async (req, res) => {
  const { username, password } = req.body || {};
  const { rows } = await pool.query('SELECT * FROM admins WHERE username=$1', [username]);
  if (!rows.length) return res.status(401).json({ error: 'invalid' });
  const ok = await bcrypt.compare(password || '', rows[0].password_hash);
  if (!ok) return res.status(401).json({ error: 'invalid' });
  req.session.isAdmin = true;
  req.session.username = username;
  res.json({ ok: true });
});

app.post('/api/admin/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

// ---- Admin reservations API (protected) ----
app.get('/api/admin/reservations', requireAuth, async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM reservations ORDER BY created_at DESC');
  res.json(rows);
});

app.put('/api/admin/reservations/:id', requireAuth, async (req, res) => {
  const { service, date, time, name, phone, note } = req.body || {};
  await pool.query(
    `UPDATE reservations SET service=$1, date=$2, time=$3, name=$4, phone=$5, note=$6 WHERE id=$7`,
    [service, date, time, name, phone, note || '', req.params.id]
  );
  res.json({ ok: true });
});

app.delete('/api/admin/reservations/:id', requireAuth, async (req, res) => {
  await pool.query('DELETE FROM reservations WHERE id=$1', [req.params.id]);
  res.json({ ok: true });
});

// ---- /admin page (login or dashboard, server-rendered) ----
app.get('/admin', (req, res) => {
  if (req.session && req.session.isAdmin) {
    return res.send(dashboardHtml());
  }
  return res.send(loginHtml());
});

function loginHtml() {
  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Connexion admin, Salyy Hair Studio</title>
<meta name="robots" content="noindex, nofollow">
<style>
  body{margin:0;background:#0e0e12;color:#f6f1e6;font-family:system-ui,sans-serif;display:flex;min-height:100vh;align-items:center;justify-content:center;}
  form{background:#1b1922;border:1px solid rgba(246,241,230,.14);border-radius:16px;padding:32px;width:100%;max-width:320px;}
  h1{font-size:1.3rem;margin:0 0 20px;}
  label{display:block;font-size:.85rem;margin-bottom:6px;color:rgba(246,241,230,.7);}
  input{width:100%;box-sizing:border-box;padding:11px 12px;margin-bottom:16px;border-radius:10px;border:1px solid rgba(246,241,230,.24);background:#221f29;color:#f6f1e6;font-size:.95rem;}
  button{width:100%;padding:12px;border:none;border-radius:999px;background:linear-gradient(135deg,#e3c785,#8a6a30);color:#20160a;font-weight:700;cursor:pointer;font-size:.95rem;}
  .err{color:#e08a7c;font-size:.85rem;margin:-8px 0 14px;min-height:1em;}
</style></head><body>
<form id="f">
  <h1>Espace administrateur</h1>
  <label for="u">Identifiant</label>
  <input id="u" name="username" autocomplete="username" required>
  <label for="p">Mot de passe</label>
  <input id="p" name="password" type="password" autocomplete="current-password" required>
  <p class="err" id="err"></p>
  <button type="submit">Se connecter</button>
</form>
<script>
document.getElementById('f').addEventListener('submit', async function(e){
  e.preventDefault();
  const username = document.getElementById('u').value;
  const password = document.getElementById('p').value;
  const r = await fetch('/api/admin/login', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({username,password})});
  if (r.ok) { location.reload(); }
  else { document.getElementById('err').textContent = 'Identifiant ou mot de passe incorrect.'; }
});
</script>
</body></html>`;
}

function dashboardHtml() {
  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Réservations, Salyy Hair Studio</title>
<meta name="robots" content="noindex, nofollow">
<style>
  body{margin:0;background:#0e0e12;color:#f6f1e6;font-family:system-ui,sans-serif;padding:20px;}
  h1{font-size:1.3rem;display:flex;justify-content:space-between;align-items:center;}
  button.logout{background:none;border:1px solid rgba(246,241,230,.24);color:#f6f1e6;padding:8px 14px;border-radius:999px;cursor:pointer;font-size:.8rem;}
  table{width:100%;border-collapse:collapse;margin-top:20px;font-size:.85rem;}
  th,td{text-align:left;padding:10px 8px;border-bottom:1px solid rgba(246,241,230,.14);vertical-align:top;}
  th{color:rgba(246,241,230,.6);font-weight:600;font-size:.75rem;text-transform:uppercase;letter-spacing:.04em;}
  input,textarea{width:100%;box-sizing:border-box;background:#221f29;color:#f6f1e6;border:1px solid rgba(246,241,230,.24);border-radius:6px;padding:6px 8px;font-size:.82rem;}
  .actions{display:flex;gap:6px;flex-wrap:wrap;}
  button.small{padding:6px 10px;border-radius:6px;border:none;cursor:pointer;font-size:.78rem;font-weight:600;}
  .save{background:#cba24e;color:#20160a;}
  .del{background:#7a2f2f;color:#fff;}
  .empty{color:rgba(246,241,230,.5);padding:30px 0;text-align:center;}
</style></head><body>
<h1>Réservations <button class="logout" id="logout">Se déconnecter</button></h1>
<div id="content">Chargement...</div>
<script>
async function load(){
  const res = await fetch('/api/admin/reservations');
  const rows = await res.json();
  const content = document.getElementById('content');
  if (!rows.length) { content.innerHTML = '<p class="empty">Aucune réservation pour le moment.</p>'; return; }
  let html = '<table><thead><tr><th>Prestation</th><th>Date</th><th>Heure</th><th>Nom</th><th>Téléphone</th><th>Note</th><th></th></tr></thead><tbody>';
  for (const r of rows) {
    html += '<tr data-id="'+r.id+'">' +
      '<td><input value="'+esc(r.service)+'" data-field="service"></td>' +
      '<td><input value="'+esc(r.date)+'" data-field="date"></td>' +
      '<td><input value="'+esc(r.time)+'" data-field="time"></td>' +
      '<td><input value="'+esc(r.name)+'" data-field="name"></td>' +
      '<td><input value="'+esc(r.phone)+'" data-field="phone"></td>' +
      '<td><textarea data-field="note">'+esc(r.note||'')+'</textarea></td>' +
      '<td class="actions"><button class="small save" onclick="saveRow('+r.id+')">Enregistrer</button>' +
      '<button class="small del" onclick="delRow('+r.id+')">Supprimer</button></td>' +
      '</tr>';
  }
  html += '</tbody></table>';
  content.innerHTML = html;
}
function esc(s){ return String(s).replace(/"/g,'&quot;').replace(/</g,'&lt;'); }
async function saveRow(id){
  const tr = document.querySelector('tr[data-id="'+id+'"]');
  const body = {};
  tr.querySelectorAll('[data-field]').forEach(function(el){ body[el.dataset.field] = el.value; });
  await fetch('/api/admin/reservations/'+id, {method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
  load();
}
async function delRow(id){
  if (!confirm('Supprimer cette réservation ?')) return;
  await fetch('/api/admin/reservations/'+id, {method:'DELETE'});
  load();
}
document.getElementById('logout').addEventListener('click', async function(){
  await fetch('/api/admin/logout', {method:'POST'});
  location.reload();
});
load();
</script>
</body></html>`;
}

init().then(() => {
  app.listen(PORT, () => console.log('Server running on port ' + PORT));
}).catch(err => {
  console.error('Failed to init DB', err);
  process.exit(1);
});
